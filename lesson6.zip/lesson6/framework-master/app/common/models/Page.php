<?php


namespace app\common\models;

use system\components\ActiveRecord;

class Page extends ActiveRecord {

}