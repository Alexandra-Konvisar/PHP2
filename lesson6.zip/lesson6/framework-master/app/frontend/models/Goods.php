<?php
namespace app\frontend\models;

use system\components\ActiveRecord;

/**
 * Class User
 * @package app\frontend\models
 */
class Goods extends ActiveRecord {

//    public function getBasket() {
//
//        return $this->hasOne(Basket::className(), ['id_good' => 'id_good']);
//    }
//
//    public static function className()
//    {
//        return get_called_class();
//    }

}