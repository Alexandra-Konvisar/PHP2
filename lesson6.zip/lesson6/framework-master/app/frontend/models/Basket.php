<?php
namespace app\frontend\models;

use system\components\ActiveRecord;

/**
 * Class Basket
 * @package app\frontend\models
 */
class Basket extends ActiveRecord {

//    public function getGoods() {
//        return $this->hasMany(Goods::className(), ['id_good' => 'id_good']);
//    }
//
//    public static function className()
//    {
//        return get_called_class();
//    }
//
//    public function getBasket() {
//
//    }
}