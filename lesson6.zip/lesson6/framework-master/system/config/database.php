<?php

return [
    'db' => [
        'user' => 'root',
        'password' => '',
        'host' => 'localhost',
        'database' => 'test2',
    ],
];
