<?php

namespace system\components;

trait Singleton {

    private function __clone() {}
    private function __wakeup() {}

}